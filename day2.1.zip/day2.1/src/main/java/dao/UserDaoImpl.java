package dao;
import org.hibernate.*;
import java.util.*;
import pojos.User;
import pojos.UserRole;

import static utils.HibernateUtils.getFactory;

import java.io.Serializable;
import java.time.LocalDate;;
public class UserDaoImpl implements UserDao{
	@Override
	public String registerUser(User user) {
		String msg= "Registration failed !!!!!!!!!!!!!!!";
		Session session=  getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try{
			// save user in Cache L1 it is previously in Java Object only
			Serializable userId = session.save(user);
			//Save user in DB 
			tx.commit();
			msg= "Registration successsful !!!!!!!!!!!!!!!"+userId;
		}catch (RuntimeException e) {
		if(tx != null) 
			tx.rollback();
		throw e;
		}
		return msg;
	}
	
	@Override
	public User getUserDetails(int userId) {
		User user = null;
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user = session.get(User.class, userId);
			tx.commit();
		}catch (RuntimeException e) {
			if(tx!= null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public List<User> getAllUserDetails(){
		List<User> user =null;
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			String jpql= "select u from User u";
			user = session.createQuery(jpql, User.class).getResultList();
			tx.commit();
		}catch (RuntimeException e) {
			if(tx!= null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public List<User> getSelectedUserDetails(LocalDate startDate ,LocalDate endDate, UserRole role ){
		List<User> user = null;
		String jpql= "select u from User u where u.regDate between :strt and :end and u.userRole =:rl";
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("strt", startDate)
					.setParameter("end", endDate)
					.setParameter("rl", role).getResultList();
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public User userLogin(String email ,String pass ){
		User user = null;
		String jpql= "select u from User u where u.email= :em and u.password=:pass";
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email)
					.setParameter("pass", pass)
					.getSingleResult();
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public List<String> getUserSelectedLogin(LocalDate startDate ,LocalDate endDate, UserRole role ){
		List<String> user = null;
		String jpql= "select u.name from User u where u.regDate between :strt and :end and u.userRole =:rl";
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user = session.createQuery(jpql, String.class).setParameter("strt",startDate)
					.setParameter("end", endDate)
					.setParameter("rl", role)
					.getResultList();
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public List<User> getUserSelectedDetails(LocalDate startDate ,LocalDate endDate, UserRole role ){
		List<User> user = null;
		String jpql= "select new pojos.User(email,regAmount,regDate) from User u where u.regDate between :strt and :end and u.userRole =:rl";
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("strt",startDate)
					.setParameter("end", endDate)
					.setParameter("rl", role)
					.getResultList();
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	
	@Override
	public String setPassword(int id,String pass){
		String mesg= "Password updation failed !!!!!!";
		User user = null;
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			user= session.get(User.class, id);
			user.setPassword(pass);
			mesg= "Password update successfully !!!!!!";
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}
	
	@Override
	public String applyDiscount(LocalDate date,double discount){
		StringBuilder mesg= new StringBuilder("Total no of users updated");
		String jpql= "update User u set u.regAmount=u.regAmount-:disc where u.regDate < :dt  ";
		Session session = getFactory().getCurrentSession();
		Transaction tx= session.beginTransaction();
		try {
			int updateAmt= session.createQuery(jpql)
					.setParameter("disc", discount)
					.setParameter("dt", date)
					.executeUpdate();
			mesg.append(updateAmt);
			tx.commit();
		}catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg.toString();
	}
	
}
