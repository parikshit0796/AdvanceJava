package tester;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;
import pojos.User;
import pojos.UserRole;
import java.time.LocalDate;
import java.util.*;

import static utils.HibernateUtils.getFactory;

public class TestHibernate {
	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			System.out.println("Hibernate up and running" + sf);
			boolean flag = true;
			while (flag) {
				System.out.println("Enter the choice :" + "\n"
						+ "1.Register User  2.Get user details  3.Display all users details  4.Display Selected User  "
						+ "\n" + "5.Login User  6.Display users names from selected date and Role  " + "\n"
						+ "7.Display User email,reg_amount and reg_date register between start and end date under Role"
						+ "\n" + "8.Update Password from Id  9.Set discount after Date  0.Exit");
				switch (sc.nextInt()) {
				case 1:
					System.out.println(
							"Enter Details: name, email, password, confirm_Passwaord, user_Role, reg_Amount, reg_Date(yyyy-MM-dd)");
					User user = new User(sc.next(), sc.next(), sc.next(), sc.next(),
							UserRole.valueOf(sc.next().toUpperCase()), sc.nextDouble(), LocalDate.parse(sc.next()));
					UserDaoImpl dao = new UserDaoImpl();
					System.out.println(dao.registerUser(user));
					break;

				case 2:
					System.out.println("Enter user Id");
					UserDaoImpl daoId = new UserDaoImpl();
					System.out.println(daoId.getUserDetails(sc.nextInt()));
					break;

				case 3:
					UserDaoImpl daoAll = new UserDaoImpl();
					daoAll.getAllUserDetails().forEach(System.out::println);
					break;

				case 4:
					System.out.println("Enter Start Date, End Date and User Role ");
					UserDaoImpl daoSelected = new UserDaoImpl();
					daoSelected.getSelectedUserDetails(LocalDate.parse(sc.next()), LocalDate.parse(sc.next()),
							UserRole.valueOf(sc.next().toUpperCase())).forEach(System.out::println);
					break;

				case 5:
					System.out.println("Enter Email and Password");
					UserDaoImpl daoLogin = new UserDaoImpl();
					daoLogin.userLogin(sc.next(), sc.next());
					break;

				case 6:
					System.out.println("Enter Start Date, End Date and User Role");
					UserDaoImpl daoSelectedDetails = new UserDaoImpl();
					daoSelectedDetails.getUserSelectedDetails(LocalDate.parse(sc.next()), LocalDate.parse(sc.next()),
							UserRole.valueOf(sc.next().toUpperCase())).forEach(System.out::println);
					break;

				case 7:
					System.out.println("Enter Start Date, End Date and User Role");
					UserDaoImpl daoSelectedLogin = new UserDaoImpl();
					daoSelectedLogin
							.getUserSelectedDetails(LocalDate.parse(sc.next()), LocalDate.parse(sc.next()),
									UserRole.valueOf(sc.next().toUpperCase()))
							.forEach(u -> System.out
									.println(u.getEmail() + " " + u.getRegAmount() + " " + u.getRegDate()));
					break;
					
				case 8:
					System.out.println("Enter user Id and new Password ");
					UserDaoImpl daoSetPass = new UserDaoImpl();
					daoSetPass.setPassword(sc.nextInt(),sc.next());
					break;
					
				case 9:
					System.out.println("Enter regDate and new Discount ");
					UserDaoImpl daoApplyDiscount = new UserDaoImpl();
					System.out.println(daoApplyDiscount.applyDiscount(LocalDate.parse(sc.next()),sc.nextDouble()));
					break;

				case 0:
					flag = false;
					break;
				}

				System.out.println(" ");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
