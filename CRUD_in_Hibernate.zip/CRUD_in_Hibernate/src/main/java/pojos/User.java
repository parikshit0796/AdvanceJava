package pojos;
import java.time.*;
import java.util.Arrays;
import javax.persistence.*;

@Entity
@Table(name= "users_tbl")
public class User {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name= "user_id")
	 private Integer userId;
	@Column(length = 20)
	 private String name;
	@Column(length = 20, unique = true)
	 private String email;
	@Column(length = 20, nullable = false)
	 private String password;
	@Transient
	 private String confirmPasswaord;
	@Enumerated(EnumType.STRING)
	@Column(name="user_role")
	 private UserRole userRole;
	@Column(name= "reg_amount")
	 private double regAmount;
	@Column(name= "reg_date")
	 private LocalDate regDate;
	@Lob
	 private byte[] image;
	 
	public User() {
		System.out.println("In default c'tor");
	}
	public User(String name, String email, String password, String confirmPasswaord, UserRole userRole,
			double regAmount, LocalDate regDate) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.confirmPasswaord = confirmPasswaord;
		this.userRole = userRole;
		this.regAmount = regAmount;
		this.regDate = regDate;
	}
	
	
	public User(String email, double regAmount, LocalDate regDate) {
		super();
		this.email = email;
		this.regAmount = regAmount;
		this.regDate = regDate;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPasswaord() {
		return confirmPasswaord;
	}
	public void setConfirmPasswaord(String confirmPasswaord) {
		this.confirmPasswaord = confirmPasswaord;
	}
	public UserRole getUserRole() {
		return userRole;
	}
	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	public LocalDate getRegDate() {
		return regDate;
	}
	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", confirmPasswaord=" + confirmPasswaord + ", userRole=" + userRole + ", regAmount=" + regAmount
				+ ", regDate=" + regDate + "]";
	}

	
	 
}
