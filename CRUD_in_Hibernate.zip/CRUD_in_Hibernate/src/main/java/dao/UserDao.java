package dao;
import java.util.List;
import java.time.*;
import pojos.User;
import pojos.UserRole;

public interface UserDao {
	
	String registerUser(User user);
	
	User getUserDetails(int userId);
	
	List<User> getAllUserDetails();
	
	List<User> getSelectedUserDetails(LocalDate startDate ,LocalDate endDate, UserRole role );
	
	public User userLogin(String email ,String pass );
	
	List<String> getUserSelectedLogin(LocalDate startDate ,LocalDate endDate, UserRole role );
	
	List<User> getUserSelectedDetails(LocalDate startDate ,LocalDate endDate, UserRole role );
	
	String setPassword(int Id,String pass);
	
	String applyDiscount(LocalDate date,double discount);
	
	String unsubscribeUser(String email); 

}
